const favorites = new Map();
let maxConfidence = 0;

function updateStats() {
  document.getElementById("favoriteCount").textContent = favorites.size;
  document.getElementById("confidenceScore").textContent = `${maxConfidence}%`;
}

function renderPrediction(container, prediction, labels) {
  const entries = Object.entries(prediction)
    .filter(([key]) => key !== "confidence")
    .map(([key, value]) => [labels[key] || key, value]);

  container.innerHTML = entries.map(([label, value]) => `
    <div class="prediction">
      <div class="row"><span>${label}</span><strong>${value}%</strong></div>
      <div class="bar"><div class="progress" style="width:${value}%"></div></div>
    </div>
  `).join("");
}

function addFavorite(id, name, sport) {
  favorites.set(id, { id, name, sport });
  renderFavorites();
  updateStats();
}

function removeFavorite(id) {
  favorites.delete(id);
  renderFavorites();
  updateStats();
}

function renderFavorites() {
  const container = document.getElementById("favoritesList");
  if (!favorites.size) {
    container.innerHTML = `<div class="empty">⭐ Aucun favori pour le moment.</div>`;
    return;
  }

  container.innerHTML = [...favorites.values()].map(item => `
    <div class="match-card favorite">
      <div class="teams">
        <span>${item.sport === "football" ? "⚽" : "🎾"} ${item.name}</span>
        <button class="secondary" data-remove="${item.id}">Supprimer</button>
      </div>
    </div>
  `).join("");

  container.querySelectorAll("[data-remove]").forEach(button => {
    button.addEventListener("click", () => removeFavorite(button.dataset.remove));
  });
}

async function loadFootballMatches() {
  const container = document.getElementById("footballMatches");
  container.innerHTML = `<div class="empty">⏳ Chargement...</div>`;

  try {
    const response = await fetch("/api/football/matches");
    const matches = await response.json();
    if (!response.ok) throw new Error(matches.error || "Erreur");

    document.getElementById("footballCount").textContent = matches.length;

    container.innerHTML = matches.map(match => `
      <article class="match-card">
        <div class="league">🏆 ${match.league}</div>
        <div class="teams">
          <div class="team">${match.home.name}</div>
          <div class="vs">VS</div>
          <div class="team">${match.away.name}</div>
        </div>
        <div class="actions">
          <button data-predict="${match.id}">🤖 Voir le pronostic</button>
          <button class="secondary" data-favorite="${match.id}">⭐ Favori</button>
        </div>
        <div id="prediction-${match.id}"></div>
      </article>
    `).join("");

    container.querySelectorAll("[data-predict]").forEach(button => {
      button.addEventListener("click", () => loadFootballPrediction(button.dataset.predict));
    });

    container.querySelectorAll("[data-favorite]").forEach(button => {
      button.addEventListener("click", () => {
        const match = matches.find(m => m.id === button.dataset.favorite);
        addFavorite(match.id, `${match.home.name} vs ${match.away.name}`, "football");
      });
    });
  } catch (error) {
    container.innerHTML = `<div class="empty">❌ ${error.message}</div>`;
  }
}

async function loadFootballPrediction(id) {
  const container = document.getElementById(`prediction-${id}`);
  container.innerHTML = `<div class="empty">🧠 Analyse...</div>`;

  try {
    const response = await fetch(`/api/football/prediction/${encodeURIComponent(id)}`);
    const data = await response.json();
    if (!response.ok) throw new Error(data.error || "Erreur");

    renderPrediction(container, data.prediction, {
      home: "Victoire domicile",
      draw: "Match nul",
      away: "Victoire extérieur"
    });

    maxConfidence = Math.max(maxConfidence, data.prediction.confidence || 0);
    updateStats();
  } catch (error) {
    container.innerHTML = `<div class="empty">❌ ${error.message}</div>`;
  }
}

async function loadTennisMatches() {
  const container = document.getElementById("tennisMatches");
  container.innerHTML = `<div class="empty">⏳ Chargement...</div>`;

  try {
    const response = await fetch("/api/tennis/matches");
    const matches = await response.json();
    document.getElementById("tennisCount").textContent = matches.length;

    container.innerHTML = matches.map(match => `
      <article class="match-card">
        <div class="league">🎾 ${match.tournament}</div>
        <div class="teams">
          <div class="team">${match.player1}</div>
          <div class="vs">VS</div>
          <div class="team">${match.player2}</div>
        </div>
        <div class="prediction" id="tennis-${match.id}"></div>
        <div class="actions">
          <button class="secondary" data-tennis-favorite="${match.id}">⭐ Favori</button>
        </div>
      </article>
    `).join("");

    matches.forEach(match => {
      renderPrediction(
        document.getElementById(`tennis-${match.id}`),
        match.prediction,
        { player1: `Victoire ${match.player1}`, player2: `Victoire ${match.player2}` }
      );
      maxConfidence = Math.max(maxConfidence, match.prediction.confidence || 0);
    });

    container.querySelectorAll("[data-tennis-favorite]").forEach(button => {
      button.addEventListener("click", () => {
        const match = matches.find(m => m.id === button.dataset.tennisFavorite);
        addFavorite(match.id, `${match.player1} vs ${match.player2}`, "tennis");
      });
    });

    updateStats();
  } catch (error) {
    container.innerHTML = `<div class="empty">❌ Impossible de charger le tennis.</div>`;
  }
}

document.getElementById("refreshFootball").addEventListener("click", loadFootballMatches);

loadFootballMatches();
loadTennisMatches();
renderFavorites();
updateStats();